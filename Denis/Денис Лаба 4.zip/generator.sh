#!/bin/bash
protoc --python_out=. schedule.proto